import React from 'react'

const MyAppointments = () => {
  return (
    <div>
        
    </div>
  )
}

export default MyAppointments